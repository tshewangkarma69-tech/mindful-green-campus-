/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Badge, SwapItem, CampusEvent, Vendor, Reward } from './types';

export const INITIAL_BADGES: Badge[] = [
  { id: '1', name: 'Waste Warrior', description: 'Reduced 10kg of waste', icon: 'Trash2', unlocked: true },
  { id: '2', name: 'Carbon Buster', description: 'Saved 50kg of CO2', icon: 'Cloud', unlocked: false },
  { id: '3', name: 'Mindful Soul', description: 'Tracked mood for 7 days', icon: 'Heart', unlocked: true },
  { id: '4', name: 'Swap Master', description: 'Completed 5 swaps', icon: 'Repeat', unlocked: false },
];

export const MOCK_SWAP_ITEMS: SwapItem[] = [
  { id: 's1', title: 'Calculus Textbook', category: 'Books', description: 'Slightly used, 12th edition.', image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=300&q=80', owner: 'Sarah', price: 200, status: 'available' },
  { id: 's2', title: 'Denim Jacket', category: 'Clothes', description: 'Vintage style, medium size.', image: 'https://images.unsplash.com/photo-1521223890158-f9f7c3d5d504?auto=format&fit=crop&w=300&q=80', owner: 'Sarah', price: 450, status: 'available' },
  { id: 's3', title: 'Coffee Press', category: 'Kitchen', description: 'French press, works perfectly.', image: 'https://images.unsplash.com/photo-1544350281-7927099fb8d5?auto=format&fit=crop&w=300&q=80', owner: 'Sarah', price: 150, status: 'available' },
];

export const MOCK_EVENTS: CampusEvent[] = [
  { id: 'e1', title: 'Vertical Gardening Workshop', date: 'April 25, 2:00 PM', location: 'Campus Greenhouse', description: 'Learn how to grow herbs in small spaces.', type: 'Workshop' },
  { id: 'e2', title: 'Sunset Meditation', date: 'April 26, 6:00 PM', location: 'Peace Garden', description: 'A guided mindfulness session at sundown.', type: 'Peace Garden' },
  { id: 'e3', title: 'Clothing Swap Meet', date: 'April 28, 10:00 AM', location: 'Student Union', description: 'Bring your old clothes and find something new!', type: 'Environment' },
  { id: 'e4', title: 'Circular Economy 101', date: 'Online Session (30 min)', location: 'Virtual Classroom', description: 'Understand how recycling and reusing build a better future.', type: 'Knowledge', isOnline: true, knowledgePoints: 100, videoUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4' },
  { id: 'e5', title: 'Renewable Power Basics', date: 'Online Session (45 min)', location: 'Virtual Classroom', description: 'Learn the fundamentals of solar and wind energy for daily life.', type: 'Knowledge', isOnline: true, knowledgePoints: 150, videoUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4' },
];

export const MOCK_VENDORS: Vendor[] = [
  { id: 'v1', name: 'Green Bean Café', category: 'Food', discount: '15% Off', description: 'Vegan and organic options.' },
  { id: 'v2', name: 'Eco-Threads', category: 'Fashion', discount: '10% Off', description: 'Sustainable clothing made from recycled materials.' },
  { id: 'v3', name: 'Refill Station', category: 'Essentials', discount: 'Buy 1 Get 1', description: 'Bring your own container for soap and grains.' },
];

export const AVAILABLE_REWARDS: Reward[] = [
  { id: 'r1', title: '15% Off Green Bean', description: 'Get a discount on any organic coffee or snack.', cost: 500, icon: 'Coffee', discountType: 'general' },
  { id: 'r2', title: '$5 Refill Credit', description: 'Applicable towards any grains or liquids at the Refill Station.', cost: 300, icon: 'Droplets', discountType: 'general' },
  { id: 'r5', title: '25% Swap Voucher', description: 'Apply 25% discount to your next Swap Hub purchase.', cost: 400, icon: 'Tag', discountType: 'swap', discountValue: 25 },
  { id: 'r3', title: 'Free Vegan Treat', description: 'Redeemable at the Earthly Eats Co. vendor stall.', cost: 450, icon: 'Cookie', discountType: 'general' },
  { id: 'r4', title: 'Composting Starter Kit', description: 'Small indoor bin and charcoal filters.', cost: 1200, icon: 'Leaf' },
];
