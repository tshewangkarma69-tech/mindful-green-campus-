/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from "@google/genai";
import { MindfulnessTip } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getDailyMindfulnessTip(): Promise<MindfulnessTip> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Generate a short daily mindfulness tip and a simple 2-minute green activity for a university student. Make it encouraging and nature-focused.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tip: { type: Type.STRING },
            activity: { type: Type.STRING },
          },
          required: ["tip", "activity"],
        },
      },
    });

    const result = JSON.parse(response.text || "{}");
    return {
      tip: result.tip || "Take a deep breath and notice the life around you.",
      activity: result.activity || "Water a plant or listen to the birds for 2 minutes."
    };
  } catch (error) {
    console.error("Error fetching tip:", error);
    return {
      tip: "Focus on your breath and find peace in small moments.",
      activity: "Observe the patterns of leaves on a tree near your next class."
    };
  }
}
