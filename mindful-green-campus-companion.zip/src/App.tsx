/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, 
  RefreshCw, 
  Calendar, 
  Award, 
  BarChart3, 
  Heart,
  Leaf,
  ShoppingBag,
  User,
  Utensils,
  ClipboardCheck,
  Camera
} from 'lucide-react';
import { UserStats, MindfulnessTip, UserProfile, SwapItem, DiningLog } from './types';
import { INITIAL_BADGES, MOCK_SWAP_ITEMS, AVAILABLE_REWARDS } from './constants';
import { getDailyMindfulnessTip } from './geminiService';
import { useLocalStorage } from './lib/storage';

// Components
import HomeView from './components/HomeView';
import DashboardView from './components/DashboardView';
import SwapView from './components/SwapView';
import EventsView from './components/EventsView';
import ImpactView from './components/ImpactView';
import ProfileView from './components/ProfileView';
import MindfulAuditTool from './components/MindfulAuditTool';
import DiningTracker from './components/DiningTracker';
import AuthView from './components/AuthView';

type View = 'home' | 'dashboard' | 'swap' | 'events' | 'impact' | 'profile' | 'audit' | 'dining';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useLocalStorage<boolean>('mgc_logged_in', false);
  const [activeView, setActiveView] = useState<View>('home');
  const [stats, setStats] = useLocalStorage<UserStats>('mgc_stats', {
    points: 840,
    badges: INITIAL_BADGES,
    moodLog: [],
    wasteReduced: 420.5,
    carbonSaved: 1200,
    savings: 342.0,
    volunteerHours: 12,
    auditScore: 78,
    claimedRewards: []
  });
  const [tip, setTip] = useState<MindfulnessTip | null>(null);
  const [profile, setProfile] = useLocalStorage<UserProfile>('mgc_profile', {
    name: 'Alex Rivera',
    email: 'alex.r@campus.edu',
    bio: 'Environment Design student. Passionate about urban gardening and reducing single-use plastics.',
    profileImage: '',
    major: 'Environmental Science',
    location: 'Vancouver, Canada'
  });
  
  const [swapItems, setSwapItems] = useLocalStorage<SwapItem[]>('mgc_swaps', MOCK_SWAP_ITEMS);
  const [diningLogs, setDiningLogs] = useLocalStorage<DiningLog[]>('mgc_dining', [
    { id: '1', date: '2026-04-22', mealType: 'Lunch', wasZeroWaste: true, notes: 'Used my bamboo cutlery at the food court.' },
    { id: '2', date: '2026-04-21', mealType: 'Dinner', wasZeroWaste: false, notes: 'Forgot my container, used take-out box.' }
  ]);

  useEffect(() => {
    getDailyMindfulnessTip().then(setTip);
  }, []);

  const handleClaimReward = (rewardId: string) => {
    const reward = AVAILABLE_REWARDS.find(r => r.id === rewardId);
    if (!reward || stats.points < reward.cost) return;

    setStats({
      ...stats,
      points: stats.points - reward.cost,
      claimedRewards: [...(stats.claimedRewards || []), rewardId]
    });
  };

  const handleSwapPurchase = (pointsToDeduct: number, rewardUsedId?: string) => {
    setStats(prev => {
      let newClaimed = [...(prev.claimedRewards || [])];
      if (rewardUsedId) {
        newClaimed = newClaimed.filter(id => id !== rewardUsedId);
      }
      return {
        ...prev,
        points: prev.points - pointsToDeduct,
        claimedRewards: newClaimed
      };
    });
  };

  const renderView = () => {
    switch (activeView) {
      case 'home': return <HomeView tip={tip} stats={stats} setStats={setStats} onClaimReward={handleClaimReward} />;
      case 'dashboard': return <DashboardView stats={stats} />;
      case 'swap': return <SwapView items={swapItems} setItems={setSwapItems} stats={stats} profile={profile} onPurchase={handleSwapPurchase} />;
      case 'events': return <EventsView stats={stats} setStats={setStats} />;
      case 'impact': return <ImpactView stats={stats} onClaimReward={handleClaimReward} />;
      case 'profile': return <ProfileView profile={profile} setProfile={setProfile} onLogout={handleLogout} />;
      case 'audit': return <MindfulAuditTool onComplete={(score) => setStats({...stats, auditScore: score})} />;
      case 'dining': return <DiningTracker logs={diningLogs} setLogs={setDiningLogs} />;
      default: return <HomeView tip={tip} stats={stats} setStats={setStats} onClaimReward={handleClaimReward} />;
    }
  };

  const handleLogin = (newProfile: UserProfile) => {
    setProfile(newProfile);
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setActiveView('home');
  };

  if (!isLoggedIn) {
    return <AuthView onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-mist text-deep-green font-sans overflow-hidden">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-white border-r border-border-mist p-6 flex flex-col justify-between shrink-0 hidden md:flex">
        <div className="space-y-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 overflow-hidden rounded-xl shadow-sm border border-forest/10 flex items-center justify-center bg-white p-1">
              <Leaf className="text-forest" size={24} />
            </div>
            <h1 className="font-bold text-lg leading-tight tracking-tight">Mindful Green<br/>Campus</h1>
          </div>
          <nav className="space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-300 ml-4 mb-2">Core Modules</p>
            <SidebarNavItem icon={<Home size={20} />} label="Home" active={activeView === 'home'} onClick={() => { setActiveView('home'); }} />
            <SidebarNavItem icon={<BarChart3 size={20} />} label="Sustainability" active={activeView === 'dashboard'} onClick={() => { setActiveView('dashboard'); }} />
            <SidebarNavItem icon={<RefreshCw size={20} />} label="Swap Hub" active={activeView === 'swap'} onClick={() => { setActiveView('swap'); }} />
            <SidebarNavItem icon={<Calendar size={20} />} label="Community" active={activeView === 'events'} onClick={() => { setActiveView('events'); }} />
            
            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-300 ml-4 mb-2 mt-6">Active Tools</p>
            <SidebarNavItem icon={<Utensils size={20} />} label="Zero-Waste" active={activeView === 'dining'} onClick={() => { setActiveView('dining'); }} />
            <SidebarNavItem icon={<ClipboardCheck size={20} />} label="Consumer Audit" active={activeView === 'audit'} onClick={() => { setActiveView('audit'); }} />
            <SidebarNavItem icon={<Award size={20} />} label="Rewards Hub" active={activeView === 'impact'} onClick={() => { setActiveView('impact'); }} />
          </nav>
        </div>
        
        <div className="space-y-4">
          <button 
            onClick={() => { setActiveView('profile'); }}
            className={`flex items-center gap-3 w-full p-3 rounded-2xl transition-all border ${activeView === 'profile' ? 'bg-highlight border-forest text-forest' : 'hover:bg-mist border-transparent text-gray-500'}`}
          >
            <div className="w-10 h-10 rounded-full bg-forest/10 border border-forest/10 overflow-hidden flex items-center justify-center shrink-0">
              {profile.profileImage ? (
                <img src={profile.profileImage} className="w-full h-full object-cover" />
              ) : (
                <User size={20} />
              )}
            </div>
            <div className="text-left overflow-hidden">
              <p className="text-xs font-bold truncate">{profile.name}</p>
              <p className="text-[10px] opacity-60 font-medium">View Profile</p>
            </div>
          </button>

          <button 
            onClick={() => handleLogout()}
            className="flex items-center gap-3 w-full p-3 rounded-2xl transition-all border hover:bg-red-50 border-transparent text-red-400 group"
          >
            <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center shrink-0 group-hover:bg-red-200 transition-colors">
              <RefreshCw size={18} className="rotate-45" />
            </div>
            <div className="text-left overflow-hidden">
              <p className="text-xs font-bold">Sign Out</p>
              <p className="text-[10px] opacity-60 font-medium">Exit Session</p>
            </div>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 md:p-8 overflow-y-auto pb-24 md:pb-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeView}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="max-w-6xl mx-auto"
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 h-20 bg-white/90 backdrop-blur-lg border-t border-border-mist flex items-center justify-around px-2 z-50 md:hidden overflow-x-auto no-scrollbar">
        <NavButton icon={<Home size={24} />} label="Home" active={activeView === 'home'} onClick={() => { setActiveView('home'); }} />
        <NavButton icon={<RefreshCw size={24} />} label="Swap" active={activeView === 'swap'} onClick={() => { setActiveView('swap'); }} />
        <NavButton icon={<Utensils size={24} />} label="Dining" active={activeView === 'dining'} onClick={() => { setActiveView('dining'); }} />
        <NavButton icon={<Award size={24} />} label="Rewards" active={activeView === 'impact'} onClick={() => { setActiveView('impact'); }} />
        <NavButton icon={<User size={24} />} label="Profile" active={activeView === 'profile'} onClick={() => { setActiveView('profile'); }} />
      </nav>
    </div>
  );
}

function SidebarNavItem({ icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`sidebar-nav-item w-full ${active ? 'active' : ''}`}
    >
      {active && <span className="absolute left-0 w-1 h-6 bg-forest rounded-full"></span>}
      {icon}
      {label}
    </button>
  );
}

function NavButton({ icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center gap-1 transition-colors ${active ? 'text-forest scale-110' : 'text-gray-400 hover:text-forest'}`}
    >
      <div className={`${active ? 'bg-highlight p-2 rounded-xl' : 'p-2'}`}>
        {icon}
      </div>
      <span className="text-[10px] font-medium uppercase tracking-tighter">{label}</span>
    </button>
  );
}

