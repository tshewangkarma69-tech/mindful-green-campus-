/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { UserStats, Reward } from '../types';
import { Award, CheckCircle2, Lock, ArrowRight, Star, TrendingUp, Sparkles, Check } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { AVAILABLE_REWARDS } from '../constants';

interface ImpactViewProps {
  stats: UserStats;
  onClaimReward: (rewardId: string) => void;
}

export default function ImpactView({ stats, onClaimReward }: ImpactViewProps) {
  const isClaimed = (id: string) => stats.claimedRewards?.includes(id);

  const leaderboardData = [
    { name: 'Sarah Jenkins', points: 1250, major: 'Biology' },
    { name: 'You', points: stats.points, major: 'Env. Science', isUser: true },
    { name: 'Michael Chen', points: 790, major: 'Engineering' },
    { name: 'Priya Sharma', points: 410, major: 'Economics' },
    { name: 'James Wilson', points: 350, major: 'Arts' },
  ].sort((a, b) => b.points - a.points);

  return (
    <div className="space-y-12 pb-12">
      {/* Achievement Row (Design HTML style) */}
      <section className="bg-deep-green text-white rounded-[40px] p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Award size={160} />
        </div>
        <div className="relative z-10 space-y-1">
          <h2 className="text-sm font-bold uppercase tracking-widest text-muted-green">Overall Performance</h2>
          <p className="text-3xl font-medium tracking-tight">Sustainability Pioneer</p>
          <p className="text-lg text-muted-green mt-2 leading-relaxed max-w-md">Your eco-actions have saved 1.2t of Carbon and reduced 420kg of waste this semester.</p>
        </div>
        <div className="flex gap-4 relative z-10">
          <AchievementBadge emoji="🏆" />
          <AchievementBadge emoji="♻️" />
          <AchievementBadge emoji="🚲" />
        </div>
      </section>

      {/* KPI Stats Grid */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <MiniImpactCard label="Carbon Offset" value={`${(stats.carbonSaved / 1000).toFixed(1)}t`} sub="CO2 equiv." color="text-forest" />
        <MiniImpactCard label="Waste Saved" value={`${stats.wasteReduced.toFixed(0)}kg`} sub="Solid waste" color="text-muted-green" />
        <MiniImpactCard label="Engagement" value="88%" sub="Social impact" color="text-forest" />
        <MiniImpactCard label="Savings" value={`$${stats.savings}`} sub="Economic" color="text-gray-400" />
      </section>

      {/* Rewards Section */}
      <section className="space-y-8">
        <div className="flex justify-between items-end border-b border-border-mist pb-4">
          <div>
            <h2 className="text-2xl font-bold">Reward Store</h2>
            <p className="text-sm text-gray-500 font-medium tracking-tight">Redeem your hard-earned points for campus perks.</p>
          </div>
          <Sparkles className="text-forest opacity-30" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {AVAILABLE_REWARDS.map(reward => {
            const claimed = isClaimed(reward.id);
            const canAfford = stats.points >= reward.cost;
            const Icon = (LucideIcons as any)[reward.icon] || Award;

            return (
              <div key={reward.id} className={`card-minimal p-6 flex items-center justify-between gap-6 transition-all ${
                claimed ? 'opacity-60 bg-mist' : 'hover:border-forest hover:shadow-md'
              }`}>
                <div className="flex items-center gap-4">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${
                    claimed ? 'bg-gray-100 text-gray-400' : 'bg-highlight text-forest'
                  }`}>
                    <Icon size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm leading-tight">{reward.title}</h4>
                    <p className="text-[10px] text-gray-500 font-medium mt-1 uppercase tracking-widest">{reward.description}</p>
                    <div className="flex items-center gap-1 mt-2">
                      <p className={`text-xs font-black ${canAfford || claimed ? 'text-forest' : 'text-red-400'}`}>
                        {reward.cost} pts
                      </p>
                    </div>
                  </div>
                </div>
                
                <button 
                  onClick={() => !claimed && canAfford && onClaimReward(reward.id)}
                  disabled={claimed || !canAfford}
                  className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
                    claimed 
                      ? 'bg-forest/10 text-forest border border-forest/20' 
                      : canAfford 
                        ? 'bg-forest text-white hover:brightness-110 active:scale-95 shadow-lg shadow-forest/10' 
                        : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  }`}
                >
                  {claimed ? (
                    <span className="flex items-center gap-1"><Check size={12} /> Claimed</span>
                  ) : 'Redeem'}
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Badges Section */}
      <section className="space-y-8">
        <div className="flex justify-between items-end border-b border-border-mist pb-4">
          <div>
            <h2 className="text-2xl font-bold">Earned Badges</h2>
            <p className="text-sm text-gray-500 font-medium tracking-tight">Milestones reached on your green journey.</p>
          </div>
          <Star className="text-forest opacity-30" />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.badges.map(badge => (
            <div key={badge.id} className={`card-minimal p-6 flex flex-col items-center text-center space-y-4 group transition-all ${
              !badge.unlocked ? 'badge-locked' : 'hover:border-forest hover:shadow-md'
            }`}>
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110 ${
                badge.unlocked ? 'bg-highlight text-forest' : 'bg-gray-100 text-gray-400'
              }`}>
                {renderBadgeIcon(badge.icon)}
              </div>
              <div>
                <h4 className="font-bold text-sm tracking-tight">{badge.name}</h4>
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">{badge.description}</p>
              </div>
              
              {!badge.unlocked && (
                <div className="flex items-center gap-1 text-[9px] font-bold uppercase tracking-widest text-gray-400 bg-mist px-2 py-1 rounded-full">
                  <Lock size={10} /> Locked
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Leaderboard Section */}
      <section className="space-y-8">
        <div className="flex justify-between items-end border-b border-border-mist pb-4">
          <div>
            <h2 className="text-2xl font-bold">Top Contributors</h2>
            <p className="text-sm text-gray-500 font-medium tracking-tight">Active leaders in the campus green network.</p>
          </div>
          <TrendingUp className="text-forest opacity-30" />
        </div>

        <div className="card-minimal overflow-hidden divide-y divide-border-mist">
          {leaderboardData.map((entry, index) => (
            <div key={entry.name} className={`flex items-center justify-between p-5 ${entry.isUser ? 'bg-highlight' : ''}`}>
              <div className="flex items-center gap-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs ${
                  index === 0 ? 'bg-forest text-white' : index === 1 ? 'bg-forest/60 text-white' : index === 2 ? 'bg-forest/30 text-deep-green' : 'bg-mist text-gray-400'
                }`}>
                  {index + 1}
                </div>
                <div>
                  <p className="font-bold text-sm">{entry.name}</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{entry.major}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-black text-forest">{entry.points}</p>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Points</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function MiniImpactCard({ label, value, sub, color }: { label: string; value: string; sub: string, color: string }) {
  return (
    <div className="card-minimal p-6 space-y-1 text-center md:text-left">
      <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">{label}</p>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
      <p className="text-[9px] font-bold text-gray-300 uppercase tracking-tighter">{sub}</p>
    </div>
  );
}

function AchievementBadge({ emoji }: { emoji: string }) {
  return (
    <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center border border-white/20 shadow-inner group transition-transform hover:scale-105">
      <span className="text-3xl">{emoji}</span>
    </div>
  );
}

function renderBadgeIcon(iconName: string) {
  const Icon = (LucideIcons as any)[iconName] || Award;
  return <Icon size={24} />;
}
