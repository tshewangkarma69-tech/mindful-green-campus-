/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MOCK_EVENTS, MOCK_VENDORS } from '../constants';
import { Calendar, MapPin, Tag, ExternalLink, CheckCircle, Play, X, BookOpen, GraduationCap } from 'lucide-react';
import { UserStats, CampusEvent } from '../types';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface EventsViewProps {
  stats: UserStats;
  setStats: (stats: UserStats) => void;
}

export default function EventsView({ stats, setStats }: EventsViewProps) {
  const [joinedEvents, setJoinedEvents] = useState<string[]>([]);
  const [completedSessions, setCompletedSessions] = useState<string[]>([]);
  const [claimedVendors, setClaimedVendors] = useState<string[]>([]);
  const [activeSession, setActiveSession] = useState<CampusEvent | null>(null);

  const handleJoin = (id: string, title: string) => {
    if (joinedEvents.includes(id)) return;
    setJoinedEvents([...joinedEvents, id]);
    setStats({ ...stats, points: stats.points + 50 });
    alert(`You've successfully joined ${title}! +50 Eco Points earned.`);
  };

  const handleCompleteKnowledge = (id: string, points: number) => {
    if (completedSessions.includes(id)) return;
    setCompletedSessions([...completedSessions, id]);
    setStats({ ...stats, points: stats.points + points });
    setActiveSession(null);
  };

  const handleClaim = (id: string, name: string) => {
    if (claimedVendors.includes(id)) return;
    setClaimedVendors([...claimedVendors, id]);
    setStats({ ...stats, points: stats.points + 20 });
    alert(`Discount code for ${name} claimed! +20 Eco Points earned.`);
  };

  return (
    <div className="space-y-12 pb-20">
      {/* Knowledge Sessions (Online) */}
      <section className="space-y-8">
        <div className="flex justify-between items-end border-b border-border-mist pb-4">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <GraduationCap className="text-forest" />
              Mindful Learning
            </h2>
            <p className="text-sm text-gray-500 font-medium">Gain knowledge through online sessions and earn rewards.</p>
          </div>
          <BookOpen className="text-forest opacity-20" size={32} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {MOCK_EVENTS.filter(e => e.isOnline).map(session => (
            <div key={session.id} className="card-minimal p-6 flex flex-col gap-4 group hover:border-forest transition-all">
              <div className="flex justify-between items-start">
                <div className="bg-forest/10 text-forest px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                  Online Course
                </div>
                <div className="flex items-center gap-1 text-[10px] font-bold text-gray-400">
                  <Play size={10} /> {session.date}
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="font-bold text-lg leading-tight">{session.title}</h3>
                <p className="text-xs text-gray-500 font-medium leading-relaxed">{session.description}</p>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="text-forest font-black text-xs">
                  +{session.knowledgePoints || 100} Points
                </div>
                <button 
                  onClick={() => completedSessions.includes(session.id) ? null : setActiveSession(session)}
                  disabled={completedSessions.includes(session.id)}
                  className={`flex items-center gap-2 px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
                    completedSessions.includes(session.id)
                      ? 'bg-mist text-forest border border-forest/20'
                      : 'bg-forest text-white hover:brightness-110 active:scale-95 shadow-lg shadow-forest/10'
                  }`}
                >
                  {completedSessions.includes(session.id) ? (
                    <><CheckCircle size={12} /> Completed</>
                  ) : (
                    <><Play size={12} fill="currentColor" /> Take Session</>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Events Section */}
      <section className="space-y-8">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-widest text-forest">Connect & In-Person</h2>
          <p className="text-3xl font-bold mt-1">Campus Calendar</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {MOCK_EVENTS.filter(e => !e.isOnline).map(event => (
            <div 
              key={event.id} 
              onClick={() => handleJoin(event.id, event.title)}
              className={`card-minimal p-6 flex flex-col md:flex-row gap-6 group transition-colors cursor-pointer ${
                joinedEvents.includes(event.id) ? 'border-forest bg-highlight/50' : 'hover:border-forest'
              }`}
            >
              <div className={`flex flex-col items-center justify-center rounded-2xl p-4 min-w-[80px] h-max transition-colors ${
                joinedEvents.includes(event.id) ? 'bg-forest text-white' : 'bg-highlight group-hover:bg-forest group-hover:text-white'
              }`}>
                <span className="text-[10px] font-bold uppercase tracking-widest opacity-60">APR</span>
                <span className="text-2xl font-bold">{event.date.match(/\d+/)?.[0]}</span>
              </div>
              <div className="flex-1 space-y-2">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-forest">{event.type}</span>
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1">
                    <MapPin size={10} /> {event.location.split(' ').pop()}
                  </span>
                </div>
                <h3 className="text-lg font-bold leading-tight group-hover:text-forest transition-colors">{event.title}</h3>
                <p className="text-xs text-gray-500 leading-relaxed font-medium line-clamp-2">{event.description}</p>
                <div className="pt-2">
                  <button className={`text-[10px] font-bold uppercase tracking-widest border-b pb-1 transition-colors ${
                    joinedEvents.includes(event.id) 
                      ? 'text-forest border-forest flex items-center gap-1' 
                      : 'text-deep-green border-border-mist group-hover:border-forest'
                  }`}>
                    {joinedEvents.includes(event.id) ? <><CheckCircle size={10} /> Registered</> : 'Join Session'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Vendors Section */}
      <section className="space-y-8">
        <div className="flex justify-between items-end border-b border-border-mist pb-4">
          <div>
            <h2 className="text-2xl font-bold">Local Green Vendors</h2>
            <p className="text-sm text-gray-500 font-medium">B-Corp certified partners nearby.</p>
          </div>
          <Tag className="text-forest opacity-30" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {MOCK_VENDORS.map(vendor => (
            <div key={vendor.id} className="card-minimal p-6 space-y-4 flex flex-col group relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-highlight rounded-bl-[100px] -mr-8 -mt-8 grayscale group-hover:grayscale-0 transition-all opacity-50" />
              
              <div className="relative z-10 space-y-1">
                <h4 className="font-bold text-lg">{vendor.name}</h4>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{vendor.category}</p>
              </div>
              
              <div className="relative z-10 flex-1">
                <p className="text-2xl font-bold text-forest">{vendor.discount}</p>
                <p className="text-xs text-gray-500 mt-1 font-medium leading-relaxed">{vendor.description}</p>
              </div>

              <button 
                onClick={() => handleClaim(vendor.id, vendor.name)}
                disabled={claimedVendors.includes(vendor.id)}
                className={`w-full btn-minimal mt-4 relative z-10 transition-all ${
                  claimedVendors.includes(vendor.id) 
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed border-none' 
                    : 'group-hover:bg-deep-green group-hover:text-white'
                }`}
              >
                {claimedVendors.includes(vendor.id) ? 'Code Claimed' : 'Get Discount'}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Learning Modal */}
      <AnimatePresence>
        {activeSession && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-deep-green/90 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white rounded-[40px] w-full max-w-4xl overflow-hidden shadow-2xl relative"
            >
              <button 
                onClick={() => setActiveSession(null)}
                className="absolute top-6 right-6 w-12 h-12 rounded-full bg-mist flex items-center justify-center text-deep-green hover:bg-forest hover:text-white transition-colors z-10"
              >
                <X size={20} />
              </button>

              <div className="grid grid-cols-1 lg:grid-cols-2">
                <div className="aspect-video lg:aspect-auto bg-black flex items-center justify-center relative">
                  {activeSession.videoUrl && (
                    <video 
                      src={activeSession.videoUrl} 
                      className="w-full h-full object-cover opacity-60"
                      autoPlay
                      loop
                    />
                  )}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-8 text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-forest flex items-center justify-center animate-pulse">
                      <Play size={24} fill="currentColor" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest opacity-80">Now Playing</p>
                      <h4 className="text-xl font-bold">{activeSession.title}</h4>
                    </div>
                  </div>
                </div>

                <div className="p-8 md:p-12 space-y-8">
                  <div className="space-y-4">
                    <h3 className="text-3xl font-bold leading-tight tracking-tight">{activeSession.title}</h3>
                    <p className="text-gray-500 font-medium leading-relaxed">
                      This session covers the essential components of {activeSession.title.toLowerCase()}. 
                      By watching this video and reviewing the curriculum, you contribute to a more sustainable campus.
                    </p>
                  </div>

                  <div className="bg-highlight p-6 rounded-3xl space-y-4">
                    <h4 className="text-xs font-black uppercase tracking-widest text-forest">Session Objectives</h4>
                    <ul className="space-y-2">
                      {[
                        'Master the core principles of circularity',
                        'Identify local waste reduction strategies',
                        'Earn Eco-Knowledge certification'
                      ].map((item, i) => (
                        <li key={i} className="text-xs font-bold flex items-center gap-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-forest" /> {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button 
                    onClick={() => handleCompleteKnowledge(activeSession.id, activeSession.knowledgePoints || 100)}
                    className="w-full py-4 rounded-full bg-forest text-white text-xs font-black uppercase tracking-widest shadow-xl shadow-forest/20 hover:brightness-110 transition-all active:scale-95"
                  >
                    Finish Session & Earn {activeSession.knowledgePoints || 100} Points
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

