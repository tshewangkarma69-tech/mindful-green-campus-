/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ClipboardCheck, ArrowRight, ArrowLeft, Leaf, TrendingUp } from 'lucide-react';
import { AuditQuestion } from '../types';

const QUESTIONS: AuditQuestion[] = [
  {
    id: '1',
    question: "How often do you use reusable containers for your campus meals?",
    options: [
      { text: "Every single time", score: 10 },
      { text: "Most of the time", score: 7 },
      { text: "Occasionally", score: 4 },
      { text: "Rarely/Never", score: 1 }
    ]
  },
  {
    id: '2',
    question: "How do you typically commute to campus?",
    options: [
      { text: "Biking or Walking", score: 10 },
      { text: "Public Transit", score: 8 },
      { text: "Carpool", score: 5 },
      { text: "Driving Alone", score: 1 }
    ]
  },
  {
    id: '3',
    question: "Do you participate in the Campus Swap Hub before buying new items?",
    options: [
      { text: "Always", score: 10 },
      { text: "Often", score: 7 },
      { text: "Seldom", score: 3 },
      { text: "Never", score: 0 }
    ]
  },
  {
    id: '4',
    question: "How mindful are you of your water and electricity usage in dorms/campus?",
    options: [
      { text: "Extremely conscious", score: 10 },
      { text: "Somewhat conscious", score: 6 },
      { text: "I don't really think about it", score: 2 }
    ]
  }
];

export default function MindfulAuditTool({ onComplete }: { onComplete: (score: number) => void }) {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [isFinished, setIsFinished] = useState(false);

  const handleSelect = (score: number) => {
    const newAnswers = [...answers];
    newAnswers[step] = score;
    setAnswers(newAnswers);
  };

  const next = () => {
    if (step < QUESTIONS.length - 1) {
      setStep(step + 1);
    } else {
      const total = answers.reduce((a, b) => a + b, 0);
      const normalized = Math.round((total / (QUESTIONS.length * 10)) * 100);
      setIsFinished(true);
      onComplete(normalized);
    }
  };

  const back = () => {
    if (step > 0) setStep(step - 1);
  };

  if (isFinished) {
    const finalScore = Math.round((answers.reduce((a, b) => a + b, 0) / (QUESTIONS.length * 10)) * 100);
    return (
      <div className="card-minimal p-10 text-center space-y-8 max-w-xl mx-auto">
        <div className="w-24 h-24 bg-forest/10 rounded-full flex items-center justify-center mx-auto">
          <Leaf className="text-forest" size={48} />
        </div>
        <div className="space-y-2">
          <h3 className="text-3xl font-bold">Your Sustainability Score</h3>
          <p className="text-sm text-gray-500 font-medium uppercase tracking-widest">Audit Complete</p>
        </div>
        <div className="text-6xl font-black text-forest">{finalScore}%</div>
        <div className="p-6 bg-highlight rounded-3xl">
          <p className="text-sm leading-relaxed text-gray-600">
            {finalScore > 80 ? "You're a Campus Champion! Your habits are paving the way for a greener future." :
             finalScore > 50 ? "Great job! You're making conscious choices, but there's room to grow." :
             "A fresh start! Use the MGPI Playbook to discover more sustainable habits."}
          </p>
        </div>
        <button 
          onClick={() => { setStep(0); setAnswers([]); setIsFinished(false); }}
          className="btn-minimal w-full"
        >
          Retake Audit
        </button>
      </div>
    );
  }

  const currentQ = QUESTIONS[step];

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-widest text-forest">Education & Scaling</h2>
          <p className="text-3xl font-bold mt-1">Consumer Audit</p>
        </div>
        <div className="text-right">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Step</p>
          <p className="text-sm font-black text-forest">{step + 1} / {QUESTIONS.length}</p>
        </div>
      </header>

      <div className="card-minimal p-8 md:p-12 space-y-8 relative overflow-hidden">
        {/* Progress bar */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-highlight">
          <div 
            className="h-full bg-forest transition-all" 
            style={{ width: `${((step + 1) / QUESTIONS.length) * 100}%` }}
          />
        </div>

        <div className="space-y-6">
          <h3 className="text-xl md:text-2xl font-bold leading-tight">{currentQ.question}</h3>
          <div className="grid gap-4">
            {currentQ.options.map((opt, i) => (
              <button
                key={i}
                onClick={() => handleSelect(opt.score)}
                className={`flex items-center justify-between p-5 rounded-2xl border-2 transition-all font-medium text-left ${
                  answers[step] === opt.score 
                    ? 'border-forest bg-highlight text-forest shadow-sm' 
                    : 'border-border-mist hover:border-forest/30'
                }`}
              >
                <span>{opt.text}</span>
                {answers[step] === opt.score && <TrendingUp size={16} />}
              </button>
            ))}
          </div>
        </div>

        <div className="flex justify-between pt-4">
          <button 
            onClick={back} 
            disabled={step === 0}
            className={`flex items-center gap-2 px-6 py-2 rounded-full text-sm font-bold transition-all ${
              step === 0 ? 'opacity-0 pointer-events-none' : 'text-gray-400 hover:text-forest'
            }`}
          >
            <ArrowLeft size={16} /> Previous
          </button>
          <button 
            onClick={next}
            disabled={answers[step] === undefined}
            className={`flex items-center gap-2 px-8 py-3 bg-forest text-white rounded-full text-sm font-bold shadow-lg transition-all active:scale-95 ${
              answers[step] === undefined ? 'opacity-50 grayscale cursor-not-allowed' : 'hover:brightness-110'
            }`}
          >
            {step === QUESTIONS.length - 1 ? "Finish Audit" : "Next Question"} <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
