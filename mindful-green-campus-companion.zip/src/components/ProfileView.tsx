/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, Upload, User, Mail, BookOpen, FileText, Check, X, SwitchCamera, Image as ImageIcon, Users, Trophy, Heart, MessageCircle, Share2, Compass, Hash, MapPin, Calendar } from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileViewProps {
  profile: UserProfile;
  setProfile: (profile: UserProfile) => void;
  onLogout: () => void;
  autoOpenCamera?: boolean;
}

export default function ProfileView({ profile, setProfile, onLogout }: ProfileViewProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [tempProfile, setTempProfile] = useState<UserProfile>(profile);
  const [activeTab, setActiveTab] = useState<'About' | 'Activity' | 'Badges'>('Activity');

  const handleSave = () => {
    setProfile(tempProfile);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setTempProfile(profile);
    setIsEditing(false);
  };

  const initialActivity = [
    { id: '1', type: 'achievement', title: 'Unlocked "Zero Waste Hero" Badge', date: '2 hours ago', icon: <Trophy size={16} /> },
    { id: '2', type: 'impact', title: 'Reduced 5kg of CO2 today', date: '5 hours ago', icon: <Heart size={16} /> },
    { id: '3', type: 'event', title: 'Joined "Campus Cleanup Drive"', date: 'Yesterday', icon: <Compass size={16} /> },
    { id: '4', type: 'post', title: 'Shared a new sustainable tip: "Composting at Home"', date: '2 days ago', icon: <ImageIcon size={16} /> },
  ];

  const [posts, setPosts] = useState(initialActivity);
  const [newPostContent, setNewPostContent] = useState('');
  const [pendingPostImage, setPendingPostImage] = useState<string | null>(null);

  const handleCreatePost = () => {
    if (!newPostContent.trim() && !pendingPostImage) return;
    const post = {
      id: Date.now().toString(),
      type: 'post',
      title: newPostContent || 'Shared a photo',
      image: pendingPostImage,
      date: 'Just now',
      icon: <ImageIcon size={16} />
    };
    setPosts([post, ...posts]);
    setNewPostContent('');
    setPendingPostImage(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-24">
      {/* Facebook-style Header Section */}
      <div className="card-minimal overflow-visible relative pb-0 rounded-b-none border-b-0 shadow-none">
        {/* Cover Photo */}
        <div className="h-48 md:h-80 bg-gradient-to-r from-forest/20 to-deep-green/20 relative rounded-t-3xl overflow-hidden group">
          {tempProfile.coverImage ? (
            <img src={tempProfile.coverImage} className="w-full h-full object-cover" referrerPolicy="no-referrer" alt="" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-mist">
              <ImageIcon size={48} className="text-forest opacity-20" />
            </div>
          )}
          
          {isEditing && (
            <label className="absolute bottom-4 right-4 bg-white px-4 py-2 rounded-lg text-forest text-[11px] font-black uppercase tracking-widest cursor-pointer shadow-xl hover:bg-mist transition-all flex items-center gap-2 border border-border-mist">
              <ImageIcon size={14} /> Edit Cover Photo
              <input 
                type="file" 
                className="hidden" 
                accept="image/*" 
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      setTempProfile({ ...tempProfile, coverImage: reader.result as string });
                    };
                    reader.readAsDataURL(file);
                  }
                }}
              />
            </label>
          )}
        </div>

        {/* Profile Picture & Info */}
        <div className="px-6 md:px-10 flex flex-col md:flex-row items-center md:items-end gap-6 -mt-12 md:-mt-20 relative z-10">
          <div className="relative">
            <div 
              className={`w-32 h-32 md:w-44 md:h-44 rounded-full border-4 border-white bg-white shadow-2xl overflow-hidden relative group ${isEditing ? 'cursor-pointer' : ''}`}
            >
              {tempProfile.profileImage ? (
                <img src={tempProfile.profileImage} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-full h-full bg-mist flex items-center justify-center text-forest">
                  <User size={64} />
                </div>
              )}
              {isEditing && (
                <label className="absolute inset-0 bg-black/30 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white cursor-pointer">
                  <ImageIcon size={32} />
                  <span className="text-[10px] font-black uppercase mt-1">Upload Picture</span>
                  <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          setTempProfile({ ...tempProfile, profileImage: reader.result as string });
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </label>
              )}
            </div>
            {isEditing && (
               <label 
                className="absolute bottom-2 right-2 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg border border-mist hover:bg-mist transition-colors group z-20 cursor-pointer"
               >
                 <ImageIcon size={20} className="text-forest" />
                 <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          setTempProfile({ ...tempProfile, profileImage: reader.result as string });
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
               </label>
            )}
          </div>

          <div className="flex-1 text-center md:text-left mb-4 md:mb-6">
            {isEditing ? (
              <div className="space-y-3 max-w-xs mx-auto md:mx-0">
                <input 
                  type="text"
                  value={tempProfile.name}
                  onChange={(e) => setTempProfile({ ...tempProfile, name: e.target.value })}
                  className="text-2xl font-black text-deep-green tracking-tight leading-none w-full bg-mist px-3 py-1 rounded-lg border border-forest/10 focus:outline-none focus:ring-2 focus:ring-forest/20"
                />
                <input 
                  type="text"
                  value={tempProfile.major}
                  onChange={(e) => setTempProfile({ ...tempProfile, major: e.target.value })}
                  className="text-forest font-bold text-lg mt-1 w-full bg-mist px-3 py-1 rounded-lg border border-forest/10 focus:outline-none focus:ring-2 focus:ring-forest/20"
                />
              </div>
            ) : (
              <>
                <h1 className="text-4xl font-black text-deep-green tracking-tight leading-none">{profile.name}</h1>
                <p className="text-forest font-bold text-lg mt-1">{profile.major}</p>
              </>
            )}
            <div className="flex items-center justify-center md:justify-start gap-4 mt-3">
              <div className="flex items-center gap-1.5 text-xs text-gray-500 font-bold">
                <Trophy size={16} /> Eco Leader
              </div>
            </div>
          </div>

          <div className="flex gap-2 mb-6">
            {!isEditing ? (
              <>
                <button 
                  onClick={() => setIsEditing(true)}
                  className="bg-forest text-white px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest shadow-lg shadow-forest/10 hover:brightness-110 active:scale-95 transition-all flex items-center gap-2"
                >
                  <SwitchCamera size={16} /> Edit Profile
                </button>
                <button 
                  onClick={onLogout}
                  className="bg-mist text-gray-500 px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-red-50 hover:text-red-500 transition-all flex items-center gap-2"
                >
                   Logout
                </button>
              </>
            ) : (
              <div className="flex gap-2">
                <button onClick={handleCancel} className="bg-mist text-gray-500 px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest">Cancel</button>
                <button onClick={handleSave} className="bg-forest text-white px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest shadow-lg shadow-forest/10">Save</button>
              </div>
            )}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 md:px-10 mt-6 pt-2 border-t border-mist flex gap-8">
          {(['Posts', 'About', 'Badges'] as const).map(tab => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab === 'Posts' ? 'Activity' : tab as any)}
              className={`text-[13px] font-bold py-4 border-b-4 transition-all ${
                (activeTab === 'Activity' && tab === 'Posts') || (activeTab === tab) 
                ? 'text-forest border-forest' 
                : 'text-gray-500 border-transparent hover:bg-mist px-2 rounded-t-lg'}`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Profile Content Body */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 px-1 md:px-0">
        {/* Left Sidebar - Intro/About */}
        <div className="lg:col-span-4 space-y-5">
          <div className="card-minimal p-5 space-y-5 shadow-sm">
            <h2 className="text-xl font-bold tracking-tight">Intro</h2>
            <div className="text-center">
              {isEditing ? (
                <textarea 
                  value={tempProfile.bio}
                  onChange={(e) => setTempProfile({ ...tempProfile, bio: e.target.value })}
                  placeholder="Tell us about your green journey..."
                  className="w-full text-sm text-gray-800 leading-relaxed font-medium bg-mist p-3 rounded-xl border border-forest/10 focus:outline-none focus:ring-2 focus:ring-forest/20 min-h-[100px]"
                />
              ) : (
                <p className="text-sm text-gray-800 leading-relaxed font-medium">"{profile.bio || "Growing a greener mind, one choice at a time."}"</p>
              )}
              {!isEditing && (
                <button 
                  onClick={() => setIsEditing(true)}
                  className="w-full mt-4 py-2 bg-mist rounded-lg text-xs font-bold hover:bg-gray-200 transition-colors"
                >
                  Edit Bio
                </button>
              )}
            </div>
            
            <div className="space-y-4 pt-2">
              <ProfileDetail icon={<BookOpen size={20} className="text-gray-400" />} text={`Studies ${isEditing ? tempProfile.major : profile.major}`} />
              {isEditing ? (
                <div className="flex items-center gap-3 px-1">
                  <MapPin size={20} className="text-gray-400 shrink-0" />
                  <input 
                    type="text"
                    value={tempProfile.location || ''}
                    onChange={(e) => setTempProfile({ ...tempProfile, location: e.target.value })}
                    placeholder="Location"
                    className="w-full bg-mist px-2 py-1 rounded text-sm focus:outline-none focus:ring-1 focus:ring-forest/20"
                  />
                </div>
              ) : (
                <ProfileDetail icon={<MapPin size={20} className="text-gray-400" />} text={`Lives in ${profile.location || 'Vancouver, Canada'}`} />
              )}
              <ProfileDetail icon={<Mail size={20} className="text-gray-400" />} text={profile.email} />
              <ProfileDetail icon={<Calendar size={20} className="text-gray-400" />} text="Joined March 2024" />
            </div>

            {!isEditing && (
              <button 
                onClick={() => setIsEditing(true)}
                className="w-full py-2 bg-mist rounded-lg text-xs font-bold hover:bg-gray-200 transition-colors"
              >
                Edit Details
              </button>
            )}
          </div>
        </div>

        {/* Right Main Content - Feed */}
        <div className="lg:col-span-8 space-y-5">
          {activeTab === 'Activity' && (
            <>
              {/* "What's on your mind" mock box */}
              <div className="card-minimal p-4 shadow-sm space-y-4">
                <div className="flex gap-3 items-center">
                  <div className="w-10 h-10 rounded-full bg-mist overflow-hidden flex-shrink-0">
                    {profile.profileImage ? (
                      <img src={profile.profileImage} className="w-full h-full object-cover" alt="" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-forest">
                        <User size={20} />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <input 
                      type="text"
                      value={newPostContent}
                      onChange={(e) => setNewPostContent(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleCreatePost()}
                      className="w-full bg-mist px-4 py-2.5 rounded-full text-sm font-medium text-gray-800 placeholder:text-gray-500 focus:outline-none focus:ring-1 focus:ring-forest/20"
                      placeholder={`What's on your mind, ${profile.name.split(' ')[0]}?`}
                    />
                    {pendingPostImage && (
                      <div className="mt-4 relative w-32 h-32 rounded-xl overflow-hidden group">
                        <img src={pendingPostImage} className="w-full h-full object-cover" />
                        <button 
                          onClick={() => setPendingPostImage(null)}
                          className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                  {newPostContent && (
                    <button 
                      onClick={handleCreatePost}
                      className="bg-forest text-white p-2 rounded-full hover:brightness-110"
                    >
                      <Check size={16} />
                    </button>
                  )}
                </div>
                <div className="flex gap-2 pt-3 border-t border-mist">
                  <label className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-mist rounded-lg text-xs font-bold text-gray-500 transition-colors cursor-pointer">
                    <ImageIcon size={20} className="text-green-500" /> Photo/video
                    <input 
                      type="file" 
                      className="hidden" 
                      accept="image/*" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            setPendingPostImage(reader.result as string);
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                  <button className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-mist rounded-lg text-xs font-bold text-gray-500 transition-colors">
                    <Users size={20} className="text-blue-500" /> Tag friends
                  </button>
                </div>
              </div>

              {/* Feed Items */}
              <div className="space-y-4">
                {posts.map(item => (
                  <div key={item.id} className="card-minimal p-0 shadow-sm overflow-hidden">
                    <div className="p-4 space-y-4">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-mist overflow-hidden flex items-center justify-center shadow-sm">
                            {item.type === 'post' ? (
                               profile.profileImage ? (
                                 <img src={profile.profileImage} className="w-full h-full object-cover" alt="" />
                               ) : (
                                 <div className="w-full h-full bg-forest flex items-center justify-center text-white">
                                   <User size={20} />
                                 </div>
                               )
                            ) : (
                               <div className="w-full h-full bg-forest flex items-center justify-center text-white">
                                  {item.icon}
                               </div>
                            )}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-gray-900 group cursor-pointer">
                              {item.type === 'post' ? profile.name : item.title}
                              {item.type === 'post' && <span className="font-normal ml-1">shared an update.</span>}
                            </p>
                            <p className="text-[11px] text-gray-500 font-bold">{item.date} • <Users size={10} className="inline mb-0.5" /></p>
                          </div>
                        </div>
                        <button className="text-gray-400 hover:bg-mist p-1.5 rounded-full transition-colors">
                          <Hash size={18} />
                        </button>
                      </div>
                      
                      {item.type === 'post' && (
                        <div className="space-y-4">
                          <p className="text-sm text-gray-800 leading-relaxed font-medium px-1">
                            {item.title}
                          </p>
                          {item.image && (
                            <div className="rounded-xl overflow-hidden border border-mist">
                              <img src={item.image} className="w-full h-auto object-cover max-h-[500px]" alt="Post" />
                            </div>
                          )}
                        </div>
                      )}

                      {item.type === 'achievement' && (
                        <div className="bg-highlight p-4 rounded-xl flex items-center gap-4 border border-forest/10">
                           <div className="w-12 h-12 bg-forest/20 rounded-full flex items-center justify-center text-forest">
                              <Trophy size={24} />
                           </div>
                           <div>
                              <p className="text-xs font-black uppercase tracking-widest text-forest">New Achievement</p>
                              <p className="font-bold text-deep-green">{item.title}</p>
                           </div>
                        </div>
                      )}
                    </div>

                    <div className="px-4 py-3 border-t border-mist flex gap-2">
                      <ActionBtn icon={<Heart size={18} />} label="Like" />
                      <ActionBtn icon={<MessageCircle size={18} />} label="Comment" />
                      <ActionBtn icon={<Share2 size={18} />} label="Share" />
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {activeTab === 'About' && (
             <div className="card-minimal p-8 space-y-8 shadow-sm">
                <h2 className="text-2xl font-black text-deep-green">About Me</h2>
                <div className="space-y-6">
                  <AboutItem label="Sustainability Goal" value="To reduce my personal carbon footprint by 50% this semester through mindful eating and waste tracking." />
                  <AboutItem label="Favorite Campus Spot" value="The Peace Garden & Greenhouse" />
                  <AboutItem label="Contact Information" value={profile.email} />
                </div>
             </div>
          )}

          {activeTab === 'Badges' && (
            <div className="card-minimal p-8 space-y-6 shadow-sm">
              <h2 className="text-2xl font-black text-deep-green">Eco Achievements</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
                  <div key={i} className="flex flex-col items-center text-center space-y-3 p-6 rounded-2xl bg-mist/30 border border-transparent hover:border-forest/20 transition-all">
                    <div className="w-20 h-20 rounded-full bg-forest/10 flex items-center justify-center text-forest shadow-inner">
                      <Trophy size={40} />
                    </div>
                    <div>
                      <p className="text-sm font-black text-deep-green">Badge Name {i}</p>
                      <p className="text-[10px] text-gray-500 font-medium">Unlocked March 2024</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}

function ProfileDetail({ icon, text }: { icon: any, text: string }) {
  return (
    <div className="flex items-center gap-3 text-gray-500 font-medium text-sm">
      <span className="text-gray-300">{icon}</span>
      {text}
    </div>
  );
}

function AboutItem({ label, value }: { label: string, value: string }) {
  return (
    <div className="space-y-1">
      <p className="text-[10px] font-black text-forest uppercase tracking-widest">{label}</p>
      <p className="text-sm font-bold text-gray-700">{value}</p>
    </div>
  );
}

function AboutMetric({ label, value }: { label: string, value: string }) {
  return (
    <div className="bg-mist p-4 rounded-xl text-center space-y-1">
      <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">{label}</p>
      <p className="text-xl font-black text-forest">{value}</p>
    </div>
  );
}

function FeedTypeBtn({ icon, label }: { icon: any, label: string }) {
  return (
    <button className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-mist rounded-lg text-xs font-bold text-gray-500 transition-colors">
      {icon} {label}
    </button>
  );
}

function ActionBtn({ icon, label }: { icon: any, label: string }) {
  return (
    <button className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-mist rounded-lg text-sm font-bold text-gray-500 transition-colors">
      <span className="text-gray-400">{icon}</span>
      {label}
    </button>
  );
}

function InputGroup({ icon, label, value, onChange }: { icon: any, label: string, value: string, onChange: (v: string) => void }) {
  return (
    <div className="space-y-1.5">
      <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-1">
        {icon} {label}
      </label>
      <input 
        type="text" 
        className="w-full px-4 py-2.5 rounded-xl bg-mist border border-border-mist focus:outline-none focus:ring-2 focus:ring-forest/10 text-sm font-medium"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

