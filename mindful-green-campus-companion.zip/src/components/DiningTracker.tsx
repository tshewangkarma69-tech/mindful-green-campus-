/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Utensils, CheckCircle2, History, Plus, X } from 'lucide-react';
import { DiningLog } from '../types';

interface DiningTrackerProps {
  logs: DiningLog[];
  setLogs: (logs: DiningLog[]) => void;
}

export default function DiningTracker({ logs, setLogs }: DiningTrackerProps) {
  const [showAdd, setShowAdd] = useState(false);
  const [newMeal, setNewMeal] = useState<'Breakfast' | 'Lunch' | 'Dinner' | 'Snack'>('Lunch');
  const [isZeroWaste, setIsZeroWaste] = useState(true);

  const addLog = () => {
    const log: DiningLog = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      mealType: newMeal,
      wasZeroWaste: isZeroWaste,
      notes: isZeroWaste ? "Great work! Every bit counts." : "Try carrying a reusable kit tomorrow!"
    };
    setLogs([log, ...logs]);
    setShowAdd(false);
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-widest text-forest">Eco-Consumption</h2>
          <p className="text-3xl font-bold mt-1">Zero-Waste Dining</p>
        </div>
        <button 
          onClick={() => setShowAdd(true)}
          className="bg-forest text-white flex items-center gap-2 px-6 py-3 rounded-2xl font-bold text-sm shadow-lg hover:brightness-110 active:scale-95 transition-all"
        >
          <Plus size={18} /> Log Meal
        </button>
      </header>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card-minimal p-6 flex flex-col items-center text-center">
          <div className="w-12 h-12 bg-forest/10 rounded-2xl flex items-center justify-center text-forest mb-4">
            <CheckCircle2 size={24} />
          </div>
          <p className="text-2xl font-black">{logs.filter(l => l.wasZeroWaste).length}</p>
          <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Zero Waste Meals</p>
        </div>
        <div className="md:col-span-2 card-minimal p-6 flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm font-bold">Conservation Streak</p>
            <p className="text-xs text-gray-500">You've logged 4 zero-waste meals in a row!</p>
          </div>
          <div className="flex -space-x-2">
            {[1,2,3,4,5].map(i => (
              <div key={i} className={`w-8 h-8 rounded-full border-2 border-white flex items-center justify-center text-[10px] font-bold ${i <= 4 ? 'bg-forest text-white' : 'bg-highlight text-gray-300'}`}>
                {i}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Logs List */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-gray-400">
          <History size={14} /> Recent Logs
        </div>
        <div className="grid grid-cols-1 gap-4">
          {logs.map(log => (
            <div key={log.id} className="card-minimal p-6 flex items-center gap-6">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${log.wasZeroWaste ? 'bg-forest/10 text-forest' : 'bg-gray-100 text-gray-400'}`}>
                <Utensils size={24} />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-lg">{log.mealType}</h4>
                    <p className="text-[10px] text-gray-400 font-bold tracking-widest uppercase">{log.date}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${log.wasZeroWaste ? 'bg-forest/10 text-forest' : 'bg-gray-100 text-gray-400'}`}>
                    {log.wasZeroWaste ? 'Zero Waste' : 'Standard'}
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-2 italic">"{log.notes}"</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Modal */}
      <AnimatePresence>
        {showAdd && (
          <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="card-minimal w-full max-w-md overflow-hidden"
            >
              <div className="p-6 border-b border-border-mist flex justify-between items-center bg-white">
                <h3 className="font-bold text-sm uppercase tracking-widest">Log Your Meal</h3>
                <button onClick={() => setShowAdd(false)} className="text-gray-400 hover:text-deep-green">
                  <X size={20} />
                </button>
              </div>
              <div className="p-8 space-y-8">
                <div className="space-y-3">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-400">Meal Type</label>
                  <div className="flex flex-wrap gap-2">
                    {['Breakfast', 'Lunch', 'Dinner', 'Snack'].map(type => (
                      <button
                        key={type}
                        onClick={() => setNewMeal(type as any)}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${newMeal === type ? 'bg-forest text-white' : 'bg-highlight text-gray-500'}`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-6 bg-highlight rounded-3xl">
                  <div>
                    <p className="text-sm font-bold leading-tight">Was it zero-waste?</p>
                    <p className="text-[10px] text-gray-500">No plastic, disposables, or food waste.</p>
                  </div>
                  <button 
                    onClick={() => setIsZeroWaste(!isZeroWaste)}
                    className={`w-14 h-8 rounded-full transition-all relative ${isZeroWaste ? 'bg-forest' : 'bg-gray-300'}`}
                  >
                    <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all ${isZeroWaste ? 'right-1' : 'left-1'}`} />
                  </button>
                </div>

                <button 
                  onClick={addLog}
                  className="w-full btn-minimal !bg-deep-green text-white"
                >
                  Save Log
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
