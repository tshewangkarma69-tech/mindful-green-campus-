/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Search, Plus, Filter, ShoppingBag, X, Package, CreditCard, MapPin, CheckCircle, Tag, Sparkles, Image as ImageIcon } from 'lucide-react';
import { SwapItem, UserStats, UserProfile } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { AVAILABLE_REWARDS } from '../constants';

interface SwapViewProps {
  items: SwapItem[];
  setItems: (items: SwapItem[]) => void;
  stats: UserStats;
  profile: UserProfile;
  onPurchase: (pointsToDeduct: number, rewardToUseId?: string) => void;
}

export default function SwapView({ items, setItems, stats, profile, onPurchase }: SwapViewProps) {
  const [activeTab, setActiveTab] = useState<'marketplace' | 'requests' | 'myshop'>('marketplace');
  const [category, setCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  
  // Cart state
  const [cartIds, setCartIds] = useState<string[]>([]);
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const [deliveryInfo, setDeliveryInfo] = useState({
    address: '',
    city: '',
    zip: '',
    card: ''
  });

  const [newItem, setNewItem] = useState<Partial<SwapItem>>({
    title: '',
    category: 'Books',
    description: '',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=300&q=80',
    owner: profile.name
  });

  const categories = ['All', 'Books', 'Clothes', 'Electronics', 'Kitchen'];

  const filteredItems = items.filter(item => {
    const matchesCategory = category === 'All' || item.category === category;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch && 
           item.status === 'available' && 
           item.owner !== profile.name &&
           !cartIds.includes(item.id);
  });

  const myItems = items.filter(item => item.owner === profile.name);
  const cartItems = items.filter(item => cartIds.includes(item.id));
  const requestedItems = items.filter(item => (item.status === 'requested' || item.status === 'sold') && item.owner !== profile.name);

  const addToCart = (id: string) => {
    if (!cartIds.includes(id)) {
      setCartIds([...cartIds, id]);
    }
  };

  const removeFromCart = (id: string) => {
    setCartIds(cartIds.filter(cid => cid !== id));
  };

  const confirmReceipt = (id: string) => {
    // Functional update ensures we're filtering against the absolute latest state
    const setter = setItems as any;
    setter((prev: SwapItem[]) => prev.filter((item: SwapItem) => item.id !== id));
    
    // Switch view only if specifically requested or if it's the last item
    if (requestedItems.length <= 1) {
      setTimeout(() => setActiveTab('marketplace'), 800);
    }
  };

  const handleAddItem = () => {
    if (newItem.title && newItem.description) {
      const item: SwapItem = {
        id: `s${Date.now()}`,
        title: newItem.title,
        category: newItem.category as any,
        description: newItem.description,
        image: newItem.image || 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=300&q=80',
        owner: profile.name,
        status: 'available',
        price: (newItem as any).price || 100
      };
      const setter = setItems as any;
      setter((prev: SwapItem[]) => [item, ...prev]);
      setShowAdd(false);
      setNewItem({ title: '', category: 'Books', description: '', image: newItem.image, owner: profile.name });
    }
  };

  const activeSwapDiscounts = AVAILABLE_REWARDS.filter(r => 
    r.discountType === 'swap' && stats.claimedRewards?.includes(r.id)
  );

  const subtotal = cartItems.reduce((acc, item) => acc + (item.price || 0), 0);
  const bestDiscount = activeSwapDiscounts.length > 0 
    ? Math.max(...activeSwapDiscounts.map(d => d.discountValue || 0)) 
    : 0;
  
  const discountAmount = Math.floor(subtotal * (bestDiscount / 100));
  const finalTotal = subtotal - discountAmount;
  const canAfford = stats.points >= finalTotal;

  const handlePayment = () => {
    if (!deliveryInfo.address || !deliveryInfo.card) {
      alert("Please fill in delivery and payment details.");
      return;
    }

    if (!canAfford) {
      alert("Insufficient points for this swap transaction.");
      return;
    }
    
    setIsProcessing(true);
    // Simulate payment processing for all items in cart
    setTimeout(() => {
      onPurchase(finalTotal, activeSwapDiscounts.length > 0 ? activeSwapDiscounts[0].id : undefined);
      
      const setter = setItems as any;
      setter((prev: SwapItem[]) => prev.map(item => 
        cartIds.includes(item.id) ? { ...item, status: 'requested' as const } : item
      ));
      setCartIds([]);
      setIsProcessing(false);
      setIsSuccess(true);
      
      // Close after a delay
      setTimeout(() => {
        setShowCheckout(false);
        setIsSuccess(false);
        setDeliveryInfo({ address: '', city: '', zip: '', card: '' });
        setActiveTab('requests');
      }, 2000);
    }, 1500);
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-widest text-forest">Community Marketplace</h2>
          <p className="text-3xl font-bold mt-1">Swap Hub</p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex bg-white rounded-xl p-1 border border-border-mist shrink-0 shadow-sm relative">
            <button 
              onClick={() => setActiveTab('marketplace')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${activeTab === 'marketplace' ? 'bg-forest text-white shadow-sm' : 'text-gray-400 hover:text-deep-green'}`}
            >
              Market
            </button>
            <button 
              onClick={() => setActiveTab('myshop')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all relative ${activeTab === 'myshop' ? 'bg-forest text-white shadow-sm' : 'text-gray-400 hover:text-deep-green'}`}
            >
              My Shop
              {myItems.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-mist text-forest text-[8px] flex items-center justify-center rounded-full border-2 border-white font-bold">
                  {myItems.length}
                </span>
              )}
            </button>
            <button 
              onClick={() => setActiveTab('requests')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all relative ${activeTab === 'requests' ? 'bg-forest text-white shadow-sm' : 'text-gray-400 hover:text-deep-green'}`}
            >
              Cart & Orders
              {(cartIds.length > 0 || requestedItems.length > 0) && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-forest text-white text-[8px] flex items-center justify-center rounded-full border-2 border-white font-bold">
                  {cartIds.length + requestedItems.length}
                </span>
              )}
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Search items..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-2.5 rounded-xl bg-white border border-border-mist focus:outline-none focus:ring-2 focus:ring-forest/10 font-medium text-sm"
              />
            </div>
            <button 
              onClick={() => setShowAdd(true)}
              className="bg-forest text-white p-2.5 rounded-xl hover:brightness-110 shadow-sm transition-all active:scale-95 flex items-center gap-2 px-4 shrink-0"
            >
              <Plus size={20} /> <span className="text-xs font-bold uppercase tracking-widest hidden sm:inline">List Item</span>
            </button>
          </div>
        </div>
      </header>

      {activeTab === 'marketplace' ? (
        <>
          <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar border-b border-border-mist">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-5 py-2 rounded-lg whitespace-nowrap text-xs font-bold uppercase tracking-widest transition-all ${
                  category === cat 
                    ? 'bg-deep-green text-white shadow-md' 
                    : 'bg-white text-gray-400 border border-border-mist'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.length > 0 ? filteredItems.map(item => (
              <div key={item.id} className="card-minimal flex flex-col group hover:shadow-md transition-all active:scale-[0.98]">
                <div className="relative h-48 overflow-hidden bg-highlight">
                  {item.image ? (
                    <img 
                      src={item.image} 
                      alt={item.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-forest/20">
                      <ImageIcon size={48} />
                    </div>
                  )}
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 rounded-lg text-[10px] font-bold text-deep-green uppercase tracking-wider shadow-sm">
                    {item.category}
                  </div>
                  <div className="absolute bottom-4 right-4 bg-forest text-white px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest shadow-lg">
                    {item.price || 0} Points
                  </div>
                </div>
                <div className="p-6 space-y-4 flex flex-col flex-1">
                  <div className="flex-1">
                    <h3 className="font-bold text-lg line-clamp-1 group-hover:text-forest transition-colors">{item.title}</h3>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Shared by {item.owner}</p>
                    <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed mt-3">{item.description}</p>
                  </div>
                  <button 
                    onClick={() => addToCart(item.id)}
                    className="w-full flex items-center justify-center gap-2 py-3 bg-highlight text-deep-green rounded-xl text-xs font-bold hover:bg-forest hover:text-white transition-all uppercase tracking-widest"
                  >
                    <ShoppingBag size={14} /> Add to Cart
                  </button>
                </div>
              </div>
            )) : (
              <div className="col-span-full py-12 flex flex-col items-center text-center space-y-4 opacity-40">
                <ShoppingBag size={48} />
                <p className="font-bold uppercase tracking-widest text-sm">No items found in this shelf.</p>
              </div>
            )}
          </div>
        </>
      ) : activeTab === 'myshop' ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-widest text-forest">My Listed Items</h3>
            <p className="text-xs font-bold text-gray-400">{myItems.length} listed</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myItems.length > 0 ? myItems.map(item => (
              <div key={item.id} className="card-minimal p-4 flex flex-col gap-4">
                <div className="relative h-32 rounded-xl overflow-hidden bg-mist">
                  {item.image ? (
                    <img src={item.image} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-forest/20">
                      <ImageIcon size={24} />
                    </div>
                  )}
                  <div className={`absolute top-2 right-2 px-2 py-1 rounded-lg text-[8px] font-black uppercase ${
                    item.status === 'available' ? 'bg-green-100 text-green-600' : 'bg-orange-100 text-orange-600'
                  }`}>
                    {item.status}
                  </div>
                </div>
                <div>
                  <h4 className="font-bold text-sm tracking-tight">{item.title}</h4>
                  <p className="text-[10px] font-bold text-forest mt-1">{item.price} pts</p>
                </div>
                <button 
                  onClick={() => {
                    const setter = setItems as any;
                    setter((prev: SwapItem[]) => prev.filter(i => i.id !== item.id));
                  }}
                  className="text-[10px] font-bold text-red-400 uppercase tracking-widest hover:text-red-600 transition-colors pt-2 border-t border-mist"
                >
                  Unlist Item
                </button>
              </div>
            )) : (
              <div className="col-span-full py-12 border-2 border-dashed border-border-mist rounded-3xl flex flex-col items-center text-center space-y-2 opacity-30">
                <Package size={32} />
                <p className="font-bold uppercase tracking-widest text-[10px]">You haven't listed anything yet.</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-12">
          {/* Cart Section */}
          <section className="space-y-6">
            <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-border-mist shadow-sm">
               <div className="flex items-center gap-3 text-deep-green">
                <ShoppingBag size={20} />
                <h3 className="text-sm font-bold uppercase tracking-widest">Shopping Cart</h3>
              </div>
              <span className="text-xs font-bold text-gray-400">{cartItems.length} Items</span>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <AnimatePresence mode="popLayout text-left">
                {cartItems.length > 0 ? (
                  <>
                    {cartItems.map(item => (
                      <motion.div 
                        key={item.id}
                        layout
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="card-minimal p-4 flex items-center gap-6 group"
                      >
                        <div className="w-20 h-20 rounded-xl bg-mist overflow-hidden flex-shrink-0">
                          {item.image ? (
                            <img src={item.image} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-forest/20">
                              <ImageIcon size={20} />
                            </div>
                          )}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-bold text-sm uppercase tracking-widest text-deep-green">{item.title}</h4>
                          <p className="text-[10px] text-gray-400 font-medium">From: {item.owner}</p>
                          <button 
                            onClick={() => removeFromCart(item.id)}
                            className="text-[10px] font-bold text-red-400 mt-2 hover:text-red-600 transition-colors uppercase tracking-widest"
                          >
                            Remove
                          </button>
                        </div>
                      </motion.div>
                    ))}
                    <motion.div layout className="pt-6 flex justify-end">
                      <button 
                        onClick={() => setShowCheckout(true)}
                        className="px-10 py-4 bg-forest text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-forest/20 hover:brightness-110 active:scale-95 transition-all flex items-center gap-3"
                      >
                        <CreditCard size={18} /> Proceed to Payment
                      </button>
                    </motion.div>
                  </>
                ) : (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="py-12 border-2 border-dashed border-border-mist rounded-3xl flex flex-col items-center text-center space-y-2 opacity-30"
                  >
                    <ShoppingBag size={32} />
                    <p className="font-bold uppercase tracking-widest text-[10px]">Your cart is empty.</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </section>

          {/* Active Orders Section */}
          <section className="space-y-6">
            <div className="flex items-center gap-3 text-gray-400 pl-4">
              <Package size={20} />
              <h3 className="text-sm font-bold uppercase tracking-widest">Fulfillment Status</h3>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <AnimatePresence mode="popLayout">
                {requestedItems.length > 0 ? requestedItems.map(item => (
                  <motion.div 
                    key={item.id}
                    layout
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.9, filter: 'blur(10px)' }}
                    transition={{ duration: 0.4, ease: "circOut" }}
                    className="card-minimal overflow-hidden border-2 border-forest/10 hover:border-forest/30 transition-all"
                  >
                    <div className="p-4 flex items-center gap-6">
                      <div className="w-20 h-20 rounded-xl bg-mist overflow-hidden flex-shrink-0 shadow-sm">
                        {item.image ? (
                          <img src={item.image} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-forest/20">
                            <ImageIcon size={20} />
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-bold text-base uppercase tracking-widest text-deep-green">{item.title}</h4>
                            <p className="text-[10px] text-gray-400 font-medium">Logistics Tracking #MG-{item.id.slice(-4)}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 mt-3">
                          <div className="flex items-center gap-1 text-[9px] font-bold text-gray-400 cursor-pointer hover:text-forest transition-colors">
                            <MapPin size={10} /> Track Shipping
                          </div>
                          <div className="flex items-center gap-1 text-[9px] font-bold text-gray-400 cursor-pointer hover:text-forest transition-colors">
                            <CreditCard size={10} /> View Receipt
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* HIGH VISIBILITY ACTION AREA */}
                    <div className="bg-forest/5 p-5 border-t border-forest/10">
                      <button 
                        onClick={() => confirmReceipt(item.id)}
                        className="w-full bg-forest text-white px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest shadow-2xl shadow-forest/40 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-4 group relative overflow-hidden"
                      >
                        <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
                        <CheckCircle size={24} className="text-white animate-pulse" /> Confirm Final Receipt
                      </button>
                      <p className="text-[9px] text-center text-gray-400 font-bold uppercase tracking-widest mt-4 animate-pulse">
                        Clicking this confirms successful swap completion
                      </p>
                    </div>
                  </motion.div>
                )) : (
                  <motion.div 
                    key="empty-orders"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="py-16 border-2 border-dashed border-border-mist rounded-3xl flex flex-col items-center text-center space-y-4 opacity-30 shadow-inner"
                  >
                    <Package size={48} className="animate-pulse" />
                    <p className="font-bold uppercase tracking-widest text-sm">No active delivery requests.</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </section>
        </div>
      )}

      {/* Checkout Modal */}
      <AnimatePresence>
        {showCheckout && (
          <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
            <motion.div 
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="card-minimal w-full max-w-md bg-white overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-border-mist flex justify-between items-center">
                <h3 className="font-bold text-sm uppercase tracking-widest">Delivery & Payment</h3>
                <button onClick={() => { if(!isProcessing) setShowCheckout(false); }} className="text-gray-400 hover:text-deep-green">
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-8">
                {isSuccess ? (
                  <div className="py-12 flex flex-col items-center text-center space-y-6">
                    <div className="w-20 h-20 bg-forest rounded-full flex items-center justify-center text-white shadow-xl shadow-forest/20">
                      <CheckCircle size={48} />
                    </div>
                    <div className="space-y-2">
                      <h4 className="text-xl font-bold">Swap Scheduled!</h4>
                      <p className="text-sm text-gray-500">The courier has been notified. Items will be delivered to your dorm soon.</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-8">
                    {/* Items Summary */}
                    <div className="space-y-4">
                      <div className="flex justify-between items-end border-b border-mist pb-2">
                        <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Order Summary</p>
                        <p className="text-[10px] font-bold text-forest">{stats.points} pts available</p>
                      </div>
                      <div className="max-h-32 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                        {cartItems.map(item => (
                          <div key={item.id} className="flex items-center justify-between bg-mist p-2 rounded-xl">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg bg-white overflow-hidden flex-shrink-0">
                                {item.image ? (
                                  <img src={item.image} className="w-full h-full object-cover" />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center text-forest/20">
                                    <ImageIcon size={14} />
                                  </div>
                                )}
                              </div>
                              <p className="text-xs font-bold text-deep-green truncate">{item.title}</p>
                            </div>
                            <span className="text-[10px] font-bold opacity-60">{item.price || 0} pts</span>
                          </div>
                        ))}
                      </div>

                      {/* Discount Section */}
                      {bestDiscount > 0 && (
                        <div className="bg-forest/5 p-3 rounded-xl border border-forest/10 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-lg bg-forest/10 flex items-center justify-center text-forest">
                              <Tag size={16} />
                            </div>
                            <div>
                              <p className="text-[10px] font-black uppercase text-forest tracking-widest">Active Reward Applied</p>
                              <p className="text-[9px] font-medium opacity-60">{bestDiscount}% Swap Discount</p>
                            </div>
                          </div>
                          <p className="text-xs font-black text-forest">-{discountAmount} pts</p>
                        </div>
                      )}

                      <div className="flex justify-between items-center px-2 pt-2">
                        <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Final Total</span>
                        <div className="text-right">
                          <p className={`text-xl font-black ${canAfford ? 'text-forest' : 'text-red-400'}`}>{finalTotal} pts</p>
                          {!canAfford && <p className="text-[9px] font-bold text-red-400 uppercase">Insufficient Balance</p>}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-5">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest flex items-center gap-2">
                          <MapPin size={12} /> Campus Delivery Destination
                        </label>
                        <input 
                          type="text"
                          placeholder="Residence Hall / Building Name"
                          className="w-full px-4 py-3 rounded-xl bg-mist border border-border-mist text-sm font-medium focus:outline-none focus:ring-2 focus:ring-forest/10"
                          value={deliveryInfo.address}
                          onChange={(e) => setDeliveryInfo({...deliveryInfo, address: e.target.value})}
                        />
                        <div className="grid grid-cols-2 gap-3">
                          <input 
                            type="text" placeholder="Zone (North/South)"
                            className="w-full px-4 py-3 rounded-xl bg-mist border border-border-mist text-sm font-medium focus:outline-none"
                            value={deliveryInfo.city}
                            onChange={(e) => setDeliveryInfo({...deliveryInfo, city: e.target.value})}
                          />
                          <input 
                            type="text" placeholder="Room/Suite #"
                            className="w-full px-4 py-3 rounded-xl bg-mist border border-border-mist text-sm font-medium focus:outline-none"
                            value={deliveryInfo.zip}
                            onChange={(e) => setDeliveryInfo({...deliveryInfo, zip: e.target.value})}
                          />
                        </div>
                      </div>

                      <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest flex items-center gap-2">
                          <CreditCard size={12} /> Student Eco-ID
                        </label>
                        <div className="relative">
                          <input 
                            type="text"
                            placeholder="Scan or Enter ID Number"
                            className="w-full px-4 py-3 rounded-xl bg-mist border border-border-mist text-sm font-medium focus:outline-none"
                            value={deliveryInfo.card}
                            onChange={(e) => setDeliveryInfo({...deliveryInfo, card: e.target.value})}
                          />
                          <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-20"><CreditCard size={18} /></div>
                        </div>
                      </div>
                    </div>

                    <button 
                      onClick={handlePayment}
                      disabled={isProcessing}
                      className="w-full py-4 bg-forest text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-forest/20 hover:brightness-110 active:scale-95 transition-all disabled:opacity-50"
                    >
                      {isProcessing ? 'Verifying Courier Availability...' : `Checkout ${cartItems.length} items`}
                    </button>
                    <p className="text-[9px] text-center text-gray-400 font-medium">Free sustainable delivery for all campus swaps.</p>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Item Modal */}
      <AnimatePresence>
        {showAdd && (
          <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="card-minimal w-full max-w-lg bg-white overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-border-mist flex justify-between items-center">
                <h3 className="font-bold text-sm uppercase tracking-widest">List New Item</h3>
                <button onClick={() => setShowAdd(false)} className="text-gray-400 hover:text-deep-green">
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-8 space-y-6">
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Item Title</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-2.5 rounded-xl bg-mist border border-border-mist focus:outline-none focus:ring-2 focus:ring-forest/10 text-sm font-medium"
                      placeholder="e.g. Scientific Calculator"
                      value={newItem.title}
                      onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Category</label>
                    <select 
                      className="w-full px-4 py-2.5 rounded-xl bg-mist border border-border-mist focus:outline-none focus:ring-2 focus:ring-forest/10 text-sm font-medium"
                      value={newItem.category}
                      onChange={(e) => setNewItem({ ...newItem, category: e.target.value as any })}
                    >
                      {categories.filter(c => c !== 'All').map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Request Points (Swap Price)</label>
                    <input 
                      type="number" 
                      className="w-full px-4 py-2.5 rounded-xl bg-mist border border-border-mist focus:outline-none focus:ring-2 focus:ring-forest/10 text-sm font-medium"
                      placeholder="e.g. 150"
                      value={(newItem as any).price || ''}
                      onChange={(e) => setNewItem({ ...newItem, price: parseInt(e.target.value) } as any)}
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Description</label>
                    <textarea 
                      className="w-full px-4 py-2.5 rounded-xl bg-mist border border-border-mist focus:outline-none focus:ring-2 focus:ring-forest/10 text-sm font-medium min-h-[100px]"
                      placeholder="Condition, year purchased, etc."
                      value={newItem.description}
                      onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex gap-3 justify-end">
                  <button 
                    onClick={() => setShowAdd(false)}
                    className="px-6 py-2 rounded-full text-sm font-bold text-gray-500 hover:bg-gray-100 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleAddItem}
                    className="px-8 py-3 bg-forest text-white rounded-full text-sm font-bold shadow-lg hover:brightness-110 active:scale-95 transition-all"
                  >
                    List Item
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

