/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { UserStats } from '../types';
import { TrendingUp, Trash2, Cloud, DollarSign, Users } from 'lucide-react';

interface DashboardViewProps {
  stats: UserStats;
}

export default function DashboardView({ stats }: DashboardViewProps) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Sustainability Column (Main feature in theme) */}
      <section className="lg:col-span-8 space-y-8">
        <div className="flex justify-between items-end">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-widest text-forest">Sustainability Dashboard</h2>
            <p className="text-3xl font-bold mt-1">Campus Impact</p>
          </div>
          <TrendingUp className="text-forest h-8 w-8" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ImpactMetric 
            icon={<Trash2 className="text-forest" />} 
            label="Waste Reduced" 
            value={`${stats.wasteReduced.toFixed(0)}kg`}
            progress={75}
            target="Goal: 560kg"
          />
          <ImpactMetric 
            icon={<Cloud className="text-muted-green" />} 
            label="Carbon Saved" 
            value={`${(stats.carbonSaved / 1000).toFixed(1)}t`}
            progress={45}
            target="Eq. to 30 trees"
          />
          <ImpactMetric 
            icon={<DollarSign className="text-gray-400" />} 
            label="Economic Gain" 
            value={`$${stats.savings}`}
            progress={100}
            target="Saved via Swap"
          />
          <ImpactMetric 
            icon={<Users className="text-forest" />} 
            label="Social Impact" 
            value="88%"
            progress={88}
            target="Community Engagement"
          />
        </div>

        {/* Weekly Progress Visualization */}
        <div className="card-minimal p-8 space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold uppercase tracking-widest">Weekly Activity Growth</h3>
            <span className="text-xs text-gray-400">Past 7 days</span>
          </div>
          <div className="h-40 flex items-end gap-3 px-2">
            {[40, 65, 45, 80, 55, 90, 75].map((h, i) => (
              <div key={i} className="flex-1 bg-highlight rounded-xl relative group h-full flex flex-col justify-end">
                <div 
                  className="bg-forest rounded-xl transition-all duration-700 w-full" 
                  style={{ height: `${h}%` }}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sidebar-style Info Panel */}
      <aside className="lg:col-span-4 space-y-6">
        <div className="card-minimal p-6 bg-deep-green text-white space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-widest text-muted-green">Top Achievement</h3>
          <div className="p-4 bg-white/10 rounded-2xl border border-white/10">
            <p className="text-sm font-medium">Waste Warrior Gold</p>
            <p className="text-[10px] text-muted-green mt-1">Earned for reducing 400kg+ waste on campus.</p>
          </div>
          <button className="w-full btn-minimal bg-white text-forest hover:bg-mist">View All Badges</button>
        </div>

        <div className="card-minimal p-6 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400">Campus Connectivity</h3>
          <ul className="space-y-4">
            <li className="flex gap-3">
              <div className="w-2 h-2 bg-forest rounded-full mt-1.5" />
              <div>
                <p className="text-xs font-bold">12 Active Swaps</p>
                <p className="text-[10px] text-gray-500">In your department</p>
              </div>
            </li>
            <li className="flex gap-3">
              <div className="w-2 h-2 bg-muted-green rounded-full mt-1.5" />
              <div>
                <p className="text-xs font-bold">3 Green Events</p>
                <p className="text-[10px] text-gray-500">Scheduled for this week</p>
              </div>
            </li>
          </ul>
        </div>
      </aside>
    </div>
  );
}

function ImpactMetric({ icon, label, value, progress, target }: any) {
  return (
    <div className="card-minimal p-6 space-y-4 shadow-none">
      <div className="flex justify-between items-end">
        <div>
          <div className="flex items-center gap-2 mb-1">
            {icon}
            <p className="text-xs font-bold uppercase tracking-widest text-gray-400">{label}</p>
          </div>
          <p className="text-2xl font-bold">{value}</p>
        </div>
      </div>
      <div className="space-y-2">
        <div className="w-full bg-highlight h-2 rounded-full">
          <div 
            className="bg-forest h-full rounded-full transition-all duration-1000" 
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-[10px] text-gray-500 font-medium">{target}</p>
      </div>
    </div>
  );
}

