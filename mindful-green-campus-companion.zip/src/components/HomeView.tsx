/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { UserStats, MindfulnessTip } from '../types';
import { Heart, Sun, CloudRain, Wind, Smile, Leaf, TrendingUp, Info } from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  BarChart,
  Bar,
  Cell
} from 'recharts';

interface HomeViewProps {
  tip: MindfulnessTip | null;
  stats: UserStats;
  setStats: (stats: UserStats) => void;
  onClaimReward: (rewardId: string) => void;
}

export default function HomeView({ tip, stats, setStats, onClaimReward }: HomeViewProps) {
  const currentMood = stats.moodLog[stats.moodLog.length - 1]?.mood;
  const isPioneerRewardClaimed = stats.claimedRewards?.includes('r1');

  // Simulated trend data based on current stats
  const performanceData = [
    { name: 'Week 1', points: 120, savings: 45, carbon: 150 },
    { name: 'Week 2', points: 280, savings: 110, carbon: 340 },
    { name: 'Week 3', points: 450, savings: 190, carbon: 620 },
    { name: 'Week 4', points: 610, savings: 260, carbon: 890 },
    { name: 'Today', points: stats.points, savings: stats.savings, carbon: stats.carbonSaved },
  ];

  const kpiData = [
    { name: 'Points', value: stats.points, color: '#166534' },
    { name: 'Savings ($)', value: stats.savings, color: '#22c55e' },
    { name: 'Carbon (kg)', value: stats.carbonSaved, color: '#14532d' },
  ];

  const handleMoodSelect = (mood: any) => {
    setStats({
      ...stats,
      moodLog: [...stats.moodLog, { date: new Date().toISOString(), mood, journal: '' }],
      points: stats.points + 5
    });
  };

  const handleJournalUpdate = (text: string) => {
    const newLog = [...stats.moodLog];
    if (newLog.length > 0) {
      newLog[newLog.length - 1].journal = text;
      setStats({ ...stats, moodLog: newLog });
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Row: Daily Tip & Mood */}
      <section className="card-minimal p-6 space-y-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex-1">
            <p className="text-xs text-forest font-bold uppercase tracking-widest mb-1">Daily Mindfulness</p>
            {tip ? (
              <p className="text-lg font-medium italic">"{tip.tip}"</p>
            ) : (
              <div className="h-6 w-48 bg-gray-100 animate-pulse rounded-md" />
            )}
          </div>
          <div className="flex items-center gap-2 bg-mist p-2 rounded-full border border-border-mist">
            <MoodButton emoji="☀️" active={currentMood === 'great'} onClick={() => handleMoodSelect('great')} />
            <MoodButton emoji="🌱" active={currentMood === 'good'} onClick={() => handleMoodSelect('good')} />
            <MoodButton emoji="☁️" active={currentMood === 'okay'} onClick={() => handleMoodSelect('okay')} />
            <MoodButton emoji="🌧️" active={currentMood === 'down'} onClick={() => handleMoodSelect('down')} />
            <span className="px-4 text-sm font-medium hidden sm:inline">
              {currentMood ? `I'm feeling ${currentMood}` : "How's your energy?"}
            </span>
          </div>
        </div>

        {/* Eco-Anxiety Journaling */}
        {currentMood && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            className="pt-4 border-t border-border-mist space-y-3"
          >
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400">
              <Smile size={14} /> Guided Reflection (Eco-Anxiety Tracker)
            </div>
            <textarea 
              className="w-full bg-mist rounded-2xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-forest/10 border border-border-mist"
              placeholder="How are you feeling about the environment today? Any mindful intentions?"
              value={stats.moodLog[stats.moodLog.length - 1]?.journal || ''}
              onChange={(e) => handleJournalUpdate(e.target.value)}
            />
          </motion.div>
        )}
      </section>

      {/* Hero Achievement / Impact Box (Replaces the old green tip box with the design's dark footer style transformed into a primary highlight) */}
      <section className="bg-deep-green text-white rounded-[40px] p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Heart size={160} />
        </div>
        <div className="relative z-10 space-y-2">
          <h2 className="text-sm font-bold uppercase tracking-widest text-muted-green">Your Achievement</h2>
          <p className="text-3xl font-medium">Sustainability Pioneer</p>
          <p className="text-lg text-muted-green mt-2">
            {isPioneerRewardClaimed 
              ? "You've redeemed your 15% discount at The Green Bean Cafe!" 
              : "You've unlocked a 15% discount at The Green Bean Cafe"}
          </p>
          <div className="pt-6 flex gap-4">
            <BadgeIcon emoji="🏆" />
            <BadgeIcon emoji="♻️" />
            <BadgeIcon emoji="🚲" />
          </div>
        </div>
        <button 
          onClick={() => !isPioneerRewardClaimed && onClaimReward('r1')}
          disabled={isPioneerRewardClaimed || stats.points < 500}
          className={`px-8 py-3 rounded-full font-bold text-sm uppercase tracking-widest relative z-10 active:scale-95 transition-all ${
            isPioneerRewardClaimed 
              ? 'bg-muted-green/20 text-muted-green border border-muted-green/30' 
              : 'bg-white text-deep-green hover:brightness-110 active:scale-95'
          } disabled:opacity-50`}
        >
          {isPioneerRewardClaimed ? 'Claimed' : 'Claim Reward'}
        </button>
      </section>

      {/* Economic KPI Impact Evaluation */}
      <section className="space-y-6">
        <div className="flex justify-between items-end border-b border-border-mist pb-4">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <TrendingUp className="text-forest" size={24} />
              Impact Evaluation
            </h2>
            <p className="text-sm text-gray-500 font-medium tracking-tight">How your sustainable choices translate to economic benefits.</p>
          </div>
          <motion.div 
            whileHover={{ scale: 1.1 }}
            className="w-10 h-10 rounded-xl bg-mist flex items-center justify-center text-forest cursor-help"
            title="Analysis based on your campus activity"
          >
            <Info size={18} />
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Trend Chart */}
          <div className="lg:col-span-2 card-minimal p-6 min-h-[300px] flex flex-col">
            <h3 className="text-xs font-black uppercase tracking-widest text-gray-400 mb-6">Growth Performance Trend</h3>
            <div className="flex-1 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={performanceData}>
                  <defs>
                    <linearGradient id="colorPoints" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#166534" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#166534" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fontWeight: 600, fill: '#94a3b8' }} 
                    dy={10}
                  />
                  <YAxis hide />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '12px' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="carbon" 
                    stroke="#166534" 
                    fillOpacity={1} 
                    fill="url(#colorPoints)" 
                    strokeWidth={3}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="points" 
                    stroke="#22c55e" 
                    fill="transparent" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="flex gap-4 mt-4">
              <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-forest">
                <div className="w-2 h-2 rounded-full bg-forest" /> Carbon Saved
              </div>
              <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-green-400">
                <div className="w-2 h-2 rounded-full bg-green-400" /> Rewards Points
              </div>
            </div>
          </div>

          {/* Distribution/Compare Chart */}
          <div className="card-minimal p-6 flex flex-col">
            <h3 className="text-xs font-black uppercase tracking-widest text-gray-400 mb-6">KPI Efficiency</h3>
            <div className="flex-1 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={kpiData} layout="vertical" margin={{ left: -20 }}>
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fontSize: 10, fontWeight: 700, fill: '#1e293b' }}
                  />
                  <Tooltip 
                    cursor={{ fill: 'transparent' }}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="value" radius={[0, 10, 10, 0]} barSize={20}>
                    {kpiData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 pt-4 border-t border-mist">
              <p className="text-[10px] font-medium text-gray-500 leading-relaxed italic">
                "Your point-to-carbon ratio is in the top 5% of campus pioneers this month."
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function MoodButton({ emoji, active, onClick }: { emoji: string; active: boolean; onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
        active ? 'bg-white shadow-md text-xl' : 'hover:bg-white/50 text-lg'
      }`}
    >
      {emoji}
    </button>
  );
}

function BadgeIcon({ emoji }: { emoji: string }) {
  return (
    <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center border border-white/20 text-2xl">
      {emoji}
    </div>
  );
}
