/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User, ArrowRight, CheckCircle } from 'lucide-react';
import { UserProfile } from '../types';

interface AuthViewProps {
  onLogin: (profile: UserProfile) => void;
}

export default function AuthView({ onLogin }: AuthViewProps) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [major, setMajor] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Simulate network delay
    setTimeout(() => {
      try {
        if (mode === 'signup') {
          if (!name || !email || !password || !major) {
            throw new Error('Please fill all fields');
          }
          const newProfile: UserProfile = {
            name,
            email,
            major,
            bio: 'Leafing my way through campus sustainability!',
            profileImage: ''
          };
          localStorage.setItem('mgc_user_account', JSON.stringify({ ...newProfile, password }));
          onLogin(newProfile);
        } else {
          const stored = localStorage.getItem('mgc_user_account');
          if (!stored) {
            throw new Error('No account found. Please sign up!');
          }
          const account = JSON.parse(stored);
          if (account.email === email && account.password === password) {
            onLogin(account);
          } else {
            throw new Error('Invalid email or password');
          }
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    }, 1200);
  };

  return (
    <div className="fixed inset-0 bg-mist flex items-center justify-center p-4 z-[200]">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8 space-y-4">
          <div className="w-24 h-24 mx-auto overflow-hidden rounded-3xl shadow-2xl shadow-forest/20 rotate-3 border-4 border-white translate-y-2 bg-white flex items-center justify-center p-2">
            <img src="/logo.png" alt="Mindful Green" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
          </div>
          <div className="pt-4">
            <h1 className="text-2xl font-bold tracking-tight">Mindful Green</h1>
            <p className="text-gray-400 text-sm font-medium uppercase tracking-widest">Green-Mind Rewards</p>
          </div>
        </div>

        <div className="card-minimal p-8 shadow-2xl">
          <div className="flex bg-mist p-1 rounded-xl mb-8">
            <button 
              onClick={() => setMode('login')}
              className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${mode === 'login' ? 'bg-white shadow-sm text-forest' : 'text-gray-400 hover:text-forest'}`}
            >
              Sign In
            </button>
            <button 
              onClick={() => setMode('signup')}
              className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${mode === 'signup' ? 'bg-white shadow-sm text-forest' : 'text-gray-400 hover:text-forest'}`}
            >
              Join Campus
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <AnimatePresence mode="wait">
              {mode === 'signup' && (
                <motion.div
                  key="signup-fields"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-5 overflow-hidden"
                >
                  <AuthInput icon={<User size={18} />} label="Full Name" type="text" placeholder="Alex Rivera" value={name} onChange={setName} />
                  <AuthInput icon={<CheckCircle size={18} />} label="Major" type="text" placeholder="Environmental Science" value={major} onChange={setMajor} />
                </motion.div>
              )}
            </AnimatePresence>

            <AuthInput icon={<Mail size={18} />} label="Campus Email" type="email" placeholder="alex@campus.edu" value={email} onChange={setEmail} />
            <AuthInput icon={<Lock size={18} />} label="Password" type="password" placeholder="••••••••" value={password} onChange={setPassword} />

            {error && (
              <p className="text-red-500 text-[10px] font-bold uppercase tracking-wider text-center">{error}</p>
            )}

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full py-4 bg-forest text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-forest/20 hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  {mode === 'login' ? 'Sign In to Portal' : 'Create Account'} <ArrowRight size={18} />
                </>
              )}
            </button>
          </form>

          <p className="text-center mt-8 text-[10px] text-gray-400 font-bold uppercase tracking-widest">
            {mode === 'login' ? "Don't have an account yet?" : "Already a member?"}
            <button 
              onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
              className="ml-2 text-forest hover:underline"
            >
              {mode === 'login' ? 'Register here' : 'Log in here'}
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
}

function AuthInput({ icon, label, type, placeholder, value, onChange }: { icon: any, label: string, type: string, placeholder: string, value: string, onChange: (v: string) => void }) {
  return (
    <div className="space-y-1.5 text-left">
      <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-2">
        {icon} {label}
      </label>
      <input 
        type={type} 
        required
        placeholder={placeholder}
        className="w-full px-4 py-3 rounded-xl bg-mist border border-border-mist focus:outline-none focus:ring-2 focus:ring-forest/10 text-sm font-medium placeholder:text-gray-300"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}
