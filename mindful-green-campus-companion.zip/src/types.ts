/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UserProfile {
  name: string;
  email: string;
  bio: string;
  profileImage: string;
  major: string;
  coverImage?: string;
  location?: string;
}

export interface UserStats {
  points: number;
  badges: Badge[];
  moodLog: MoodEntry[];
  wasteReduced: number; // in kg
  carbonSaved: number; // in kg CO2
  savings: number; // in USD
  volunteerHours: number;
  auditScore?: number;
  claimedRewards?: string[]; // IDs of claimed rewards
}

export interface Reward {
  id: string;
  title: string;
  description: string;
  cost: number;
  icon: string;
  discountType?: 'swap' | 'general';
  discountValue?: number; // percentage or fixed
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
}

export interface MoodEntry {
  date: string;
  mood: 'great' | 'good' | 'okay' | 'stressed' | 'down';
  journal?: string;
}

export interface DiningLog {
  id: string;
  date: string;
  mealType: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
  wasZeroWaste: boolean;
  notes: string;
}

export interface AuditQuestion {
  id: string;
  question: string;
  options: { text: string; score: number }[];
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  points: number;
  avatar?: string;
  rank: number;
}

export interface SwapItem {
  id: string;
  title: string;
  category: 'Books' | 'Clothes' | 'Electronics' | 'Kitchen' | 'Other';
  description: string;
  image: string;
  owner: string;
  status?: 'available' | 'requested' | 'sold';
  price?: number; // in points
}

export interface CampusEvent {
  id: string;
  title: string;
  date: string;
  location: string;
  description: string;
  type: 'Workshop' | 'Peace Garden' | 'Cultural' | 'Environment' | 'Knowledge';
  isOnline?: boolean;
  videoUrl?: string;
  knowledgePoints?: number;
}

export interface Vendor {
  id: string;
  name: string;
  category: string;
  discount: string;
  description: string;
}

export interface MindfulnessTip {
  tip: string;
  activity: string;
}
